
<?php

$conn = mysqli_connect('localhost' , 'kartik' , 'kartik@1234','bookstore');

if(!$conn){
	echo 'connection error' . mysqli_connect_error();
}
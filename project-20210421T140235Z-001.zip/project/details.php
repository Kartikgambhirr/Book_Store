<?php 

include ("config/connect.php"); 

if(isset($_POST['delete'])){

	$y =mysqli_real_escape_string($conn , $_POST['id_to_delete']) ;
	$sql = "DELETE FROM books WHERE rollno = $y";

	if(mysqli_query($conn , $sql)){

		header('Location : index.php');
	}  {

		echo 'query error: ' . mysqli_error($conn);
	}
}


if(isset($_GET['id'])){

	$z = mysqli_real_escape_string($conn , $_GET['id']);

	$sql= "SELECT * FROM books  WHERE rollno = $z " ;
	
	$result = mysqli_query($conn , $sql);
	
	$books = mysqli_fetch_assoc($result);
	
	mysqli_free_result($result);
	
	mysqli_close($conn);
	
//	print_r($books);

}

?> 



<!DOCTYPE html>
<html>
<head><style type="text/css">
	#fv{
		color: white;
	}
</style></head>

<?php include "hdrnftr/interface.php" ?>





<div class="container center">
	<?php if($books){ ?>                      <!--  if(books) :      (in php)-->
		<h4 id="fv"><?php echo htmlspecialchars($books['title']) ?></h4>
		<p  id="fv"> Created by : <?php echo htmlspecialchars($books['email']) ?></p>
		<p  id="fv"><?php echo date($books['created_at']); ?> </p>
			<h5  id="fv">Authors : </h5>
					<h4  id="fv"><?php echo htmlspecialchars($books['authors']) ?></h4>


		<form action="details.php" method="POST">
			<input type="hidden" name="id_to_delete" value="<?php echo $books['rollno'] ?>">
			<input type="submit" name="delete" value="Delete" class="btn brand z-depth-0 center">
		</form>	





<?php } else  { ?>     <!-- else :  (in php)-->

     <h5><?php echo 'no such book in the store'; ?></h5>    <!--  OR <h4>no book</h4>-->

  <?php }  ?>     <!--    endif;    ( in php)   -->

</div> 

<?php include "hdrnftr/footer.php" ?>

</html>
<!-- header -->
<html>
<head>
	<title>LIBRUARY</title>
	 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
	 <style type= "text/css">
	 	.brand{
	 		background-color: #8E524F;
	 	}
	 	form{

	 		align :center;
	 		max-width: 460px;
	 		margin: 30px;
	 		padding: 40px;
	 	}
	 	#we{
	 		background-color:	#E69A4C;
	 	}
	 	#hello{
	 		color: #67210C;
	 		font-size: 35px;

	 	
	 	}
	 	#search{
	 		background-color: white;
	 		margin-right: 156px;
	 		border-spacing: 20px;
	 	}
	 	.book{
	 		width: 100px;
	 		margin: 20px auto;
	 		display: block;
	 		position :relative;

	 	}
	 	
	 		
	 </style>
</head>
<body background="1.jpeg">
<nav class=" z-depth-0" id="we" >
<div class="container" align="center">
<a id="hello" href="show.php" class="left" >BOOK STORE</a>
<ul id="nav-mobile" class="right  hide-on-small-and-down">
	<li><input type="text" id="search" placeholder="Search a Book">
	<li><a href="Contact.php " class="btn brand z-depth-50">Contact</a></li>
	<li><a href="addform.php " class="btn brand z-depth-50">Add Book</a></li>
	<li><a href="about.php " class="btn brand z-depth-50">About</a></li>
	<li><a href="Carttry " class="btn brand z-depth-50">My Cart</a></li>
</ul>
</div>
</nav>

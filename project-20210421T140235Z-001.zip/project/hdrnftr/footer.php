<footer class="section">
	<div class="right grey-text">Copyright </div>
</footer></body>

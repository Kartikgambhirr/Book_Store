<!-- header -->
<html>
<head>
	<title>LIBRUARY</title>
	 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
	 <style type= "text/css">
	 	.brand{
	 		background-color: skyblue;
	 	}
	 	form{

	 		align :center;
	 		max-width: 460px;
	 		margin: 30px;
	 		padding: 40px;
	 	}
	 	.brand-text{
	 		color: #cbb09c;
	 	}
	 	#hello{
	 		color: #67210C;

	 		font-size: 35px;
	 	
	 	}
	 	#re{
	 		background-color: #8E524F;
	 	}
	 	#we{
	 			 		background-color:	#E69A4C;

	 	}
	 	body{
	 		background-color: 
	 	}

	 </style>
</head>
<body class=" lighten-4">
<nav class=" z-depth-0" id="we">
<div class="container" align="center">
<a id="hello" href="show.php" class="left" >BOOKS</a>
<ul id="nav-mobile" class="right  hide-on-small-and-down">
		<li><a href=" contact.php" class="btn brand z-depth-50" id="re">Contact</a></li>
	
</ul>
</div>
</nav>

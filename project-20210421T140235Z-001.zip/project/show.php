<!-- card , index.php-->

<?php include "config/connect.php" ?>
<?php

$sql ='SELECT rollno ,email,title,authors FROM books ORDER BY created_at';

$result = mysqli_query($conn , $sql);

$books = mysqli_fetch_all($result , MYSQLI_ASSOC);

// not imp 
mysqli_free_result($result);
// not imp
mysqli_close($conn);

//print_r($books);
explode(',', $books[0]['authors'])
?>

<!DOCTYPE html>
<html>
<head>
	<style type="text/css">
		#qw {
			box-shadow: 50px 100px ;
			background-color: #8E524F;
		}
	</style>
</head>
<body>
<?php include "try.php" ?>

<h4 class="center red-text "></h4>
<div class="container ">
	<div class="row ">
		<?php foreach( $books as $book){ ?>

			<div class="col s6 md3 ">
				<div class="card z-depth-0 " id="qw">
					<img src="img/book.png" class="book">
					<div class="card-content center " id="we">

					<h4> TITLE : <?php echo htmlspecialchars($book['title']); ?> </h4>
					
					<ul>Author : <br>
						<?php foreach(explode(',', $book['authors']) as $easy){ ?>

							<li><?php echo htmlspecialchars($easy) ?></li>
						<?php } ?>
					</ul>	
								
					</div>
				
					<div class="card-action right-align">
						<a class="brand-text" href="details.php?id=<?php echo $book['rollno']?>">more info</a>
						<a href="Carttry " class="btn btn-primary">Add to MY  CART</a>
					</div>
			</div>
		</div>

		<?php } ?>
	</div>
</div>



<?php include "hdrnftr/footer.php" ?>



</body>
</html>



